# replit.md

## Overview

This is a full-stack web application built with React frontend and Express backend. The project appears to be a portfolio website for "Jayvon C" based on the HTML title. It uses a modern TypeScript-based stack with PostgreSQL database support via Drizzle ORM, and features a comprehensive UI component library powered by shadcn/ui.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state management
- **Styling**: Tailwind CSS with CSS variables for theming (supports light/dark mode)
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Build Tool**: Vite with custom plugins for Replit integration

The frontend is located in the `client/` directory with:
- `client/src/App.tsx` - Main application entry with routing setup
- `client/src/components/ui/` - Comprehensive shadcn/ui component library
- `client/src/hooks/` - Custom React hooks (mobile detection, toast notifications)
- `client/src/lib/` - Utility functions and query client configuration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with tsx for TypeScript execution
- **API Pattern**: RESTful API with routes prefixed by `/api`
- **Build Process**: esbuild for production bundling with selective dependency bundling

The backend is located in the `server/` directory with:
- `server/index.ts` - Express app setup with middleware
- `server/routes.ts` - API route registration
- `server/storage.ts` - Data access layer with interface abstraction
- `server/vite.ts` - Vite dev server integration for development
- `server/static.ts` - Static file serving for production

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` - Contains database table definitions
- **Migrations**: Generated to `./migrations` directory
- **Current Schema**: Users table with id, username, and password fields
- **Validation**: Zod schemas generated from Drizzle schemas via drizzle-zod

The storage layer uses an interface pattern (`IStorage`) allowing for easy swapping between:
- `MemStorage` - In-memory storage for development/testing
- Database storage can be implemented using the same interface

### Shared Code
The `shared/` directory contains code shared between frontend and backend:
- Database schema definitions
- Zod validation schemas
- TypeScript types derived from schemas

## External Dependencies

### Database
- **PostgreSQL**: Primary database (configured via `DATABASE_URL` environment variable)
- **Drizzle Kit**: Database migration and schema push tool (`npm run db:push`)

### UI Framework Dependencies
- **Radix UI**: Headless UI component primitives (accordion, dialog, dropdown, etc.)
- **Tailwind CSS**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **Embla Carousel**: Carousel/slider functionality
- **Recharts**: Charting library for data visualization

### Session Management
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **express-session**: Session middleware

### Development Tools
- **Vite**: Frontend build tool with HMR
- **Replit Plugins**: Custom Vite plugins for Replit environment (cartographer, dev-banner, runtime-error-modal)

### Potential Integrations (dependencies present but not yet configured)
- **OpenAI / Google Generative AI**: AI integration capabilities
- **Stripe**: Payment processing
- **Nodemailer**: Email sending
- **Passport**: Authentication framework with local strategy support